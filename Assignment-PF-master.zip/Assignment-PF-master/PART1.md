# Part 1

## Video Demo

[Video Demo](https://youtu.be/y225kK8UKEY).

## Minimum Requirements

### Completed

List all the features completed.

1. Able to customize the gameboard.
2. Alien able to move.

### To Do

List all the features not yet done. Remove this section if there is no incomplete requirements.

1. Alien able to get the objects.


## Additional Features

Describe the additional features that has been implemented.

## Contributions

List down the contribution of each group members.

### Leong Jia Yi

1. Randomly generate game board.
2. Implement all game objects.


### Chai Di Sheng

1. Alien movement and attack behaviour.



## Problems Encountered & Solutions

Describe the problems encountered and provide the solutions / plan for the solutions.

Problems encountered:

a)The code unable to execute a gameboard.

Solution :
a)Restart the code again and it will be able to execute.
